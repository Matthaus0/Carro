function mostrarCarros() {
    // Instanciando um Carro Elétrico
    const meuCarroEletrico = new CarroEletrico("BYD", "Dolphin", 2024, 291);

    // Selecionando a div do HTML onde o resultado será inserido
    const resultadoDiv = document.getElementById("resultado");

    // Inserindo o texto formatado no HTML
    resultadoDiv.innerHTML = `
        <p><strong>Veículo Cadastrado:</strong> ${meuCarroEletrico.obterDetalhes()}</p>
    `;
}