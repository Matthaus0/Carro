// Classe Pai (Base)
class Carro {
    constructor(marca, modelo, ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }

    obterDetalhes() {
        return `${this.marca} ${this.modelo} (${this.ano})`;
    }
}

// Classe Filha (Herança)
class CarroEletrico extends Carro {
    constructor(marca, modelo, ano, autonomiaBateria) {
        super(marca, modelo, ano); // Chama o construtor da classe Pai
        this.autonomiaBateria = autonomiaBateria; // propriedade específica
    }

    // Sobrescrita ou extensão do método
    obterDetalhes() {
        return `${super.obterDetalhes()} - Autonomia: ${this.autonomiaBateria} km`;
    }
}